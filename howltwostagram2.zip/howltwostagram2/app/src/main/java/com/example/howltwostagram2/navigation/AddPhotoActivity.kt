package com.example.howltwostagram2.navigation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AddPhotoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_photo)
    }
}
